# Tanvir Ahmmed — Anime Liquid Glass (v6)

Dark cherry + blur purple theme, Apple-style liquid glass, sakura petals.
Open index.html in a browser.
